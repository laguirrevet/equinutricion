const CACHE = 'equinutricion-v1';
const ASSETS = [
  '/equinutricion/',
  '/equinutricion/index.html',
  '/equinutricion/manifest.json',
  '/equinutricion/icon-192.png',
  '/equinutricion/icon-512.png'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(cached => cached || fetch(e.request)));
});
